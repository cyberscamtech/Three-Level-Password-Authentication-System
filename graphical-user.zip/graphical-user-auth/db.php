<?php
$host ="localhost";
$db_user ="root";
$db_name = "gpa";
$db_pass ="";

$db = new mysqli($host,$db_user,$db_pass,$db_name);


?>