		<?php 

		$server="localhost";

		$user="root";

		$password="";

		$database="gpa";

		$con=mysqli_connect($server,$user,$password,$database);

		if(!$con)

		echo 'Connection failed !';

		?>
		

	