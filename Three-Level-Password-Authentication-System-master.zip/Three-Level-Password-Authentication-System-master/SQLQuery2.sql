﻿create table COLOR(
	val text
);