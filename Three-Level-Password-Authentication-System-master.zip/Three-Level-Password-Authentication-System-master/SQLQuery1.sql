﻿CREATE TABLE LOGIN(
	USERNAME varchar(50),
	PASSWORD varchar(50)
);

CREATE TABLE COLOR(
	val varchar(MAX)
);

CREATE TABLE picture(
	picture varchar
);